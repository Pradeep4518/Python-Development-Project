import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score

data = pd.read_csv('data/house_prices.csv')

print(data.head())
print(data.shape)
print(data.isnull().sum())

print(data['Price'].mean())

data['Location'] = data['Location'].replace('Urban', 2)
data['Location'] = data['Location'].replace('Suburban', 1)
data['Location'] = data['Location'].replace('Rural', 0)

x = data[['Rooms', 'Size_SqFt', 'Age_Years', 'Garage', 'Pool', 'Location']]
y = data['Price']

x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.2)

model = LinearRegression()
model.fit(x_train, y_train)

pred = model.predict(x_test)
print(r2_score(y_test, pred))

data.groupby('Location')['Price'].mean().plot(kind='bar')
plt.title('Average Price by Location')
plt.xlabel('Location')
plt.ylabel('Price')
plt.tight_layout()
plt.savefig('outputs/bar_chart.png')
plt.close()

plt.scatter(y_test, pred)
plt.title('Actual vs Predicted')
plt.xlabel('Actual Price')
plt.ylabel('Predicted Price')
plt.savefig('outputs/scatter_plot.png')
plt.close()

sns.heatmap(data[['Rooms','Size_SqFt','Age_Years','Garage','Pool','Price']].corr(), annot=True)
plt.title('Heatmap')
plt.savefig('outputs/heatmap.png')
plt.close()

f = open('outputs/analysis.txt', 'w')
f.write('Author: Pradeep\n')
f.write('Average Price: ' + str(data['Price'].mean()) + '\n')
f.write('R2 Score: ' + str(r2_score(y_test, pred)) + '\n')
f.write('\nLocation wise price:\n')
f.write(str(data.groupby('Location')['Price'].mean()) + '\n')
f.write('\nBigger size means higher price\n')
f.write('Urban houses are more expensive\n')
f.write('Older houses have lower price\n')
f.close()

print('done')
