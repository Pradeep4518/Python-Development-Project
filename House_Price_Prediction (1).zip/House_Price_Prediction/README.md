# House Price Prediction

This project uses Linear Regression to predict house prices based on features like number of rooms, location, size, age, garage, and pool.

## Project Structure

```
House_Price_Prediction/
│
├── data/
│   └── house_prices.csv
│
├── outputs/
│   ├── bar_chart.png
│   ├── scatter_plot.png
│   ├── heatmap.png
│   └── analysis.txt
│
├── house_price_prediction.py
├── README.md
└── requirements.txt
```

## How to Run

```
pip install -r requirements.txt
python house_price_prediction.py
```

## Dataset

The dataset is inspired by the Kaggle House Prices dataset. It has 500 rows and the following columns:

- Id
- Location (Urban, Suburban, Rural)
- Rooms
- Size_SqFt
- Age_Years
- Garage (0 or 1)
- Pool (0 or 1)
- Price (target)

## Model Used

Linear Regression from scikit-learn.

Steps:
1. Load the CSV
2. One-hot encode Location column
3. Split into train and test sets (80/20)
4. Scale features using StandardScaler
5. Train the model
6. Evaluate using R2, MAE, RMSE

## Results

- R2 Score  : 0.9818
- MAE       : $15,965
- RMSE      : $19,836

## Output Files

- bar_chart.png     - Average price by location
- scatter_plot.png  - Actual vs Predicted prices
- heatmap.png       - Correlation between features
- analysis.txt      - Summary report
