import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

df = pd.read_csv('data/employees.csv')

print(df.head())
print(df.shape)
print(df.isnull().sum())

print(df['Salary'].mean())
print(df['Experience_Years'].mean())
print(df['Performance'].mean())

print(df.groupby('Department')['Salary'].mean())

df.groupby('Department')['Salary'].mean().plot(kind='bar')
plt.title('Average Salary by Department')
plt.xlabel('Department')
plt.ylabel('Salary')
plt.tight_layout()
plt.savefig('outputs/bar_chart.png')
plt.close()

plt.scatter(df['Experience_Years'], df['Salary'])
plt.title('Experience vs Salary')
plt.xlabel('Experience Years')
plt.ylabel('Salary')
plt.savefig('outputs/scatter_plot.png')
plt.close()

sns.heatmap(df[['Age','Experience_Years','Salary','Performance']].corr(), annot=True)
plt.title('Heatmap')
plt.savefig('outputs/heatmap.png')
plt.close()

f = open('outputs/analysis.txt', 'w')
f.write('Author: Pradeep\n')
f.write('Average Salary: ' + str(df['Salary'].mean()) + '\n')
f.write('Average Experience: ' + str(df['Experience_Years'].mean()) + '\n')
f.write('Average Performance: ' + str(df['Performance'].mean()) + '\n')
f.write('\nDepartment wise salary:\n')
f.write(str(df.groupby('Department')['Salary'].mean()) + '\n')
f.write('\nEngineering has highest salary\n')
f.write('More experience means more salary\n')
f.write('Performance is almost same in all departments\n')
f.close()

print('done')
