import numpy as np

print("Matrix Operations Tool")
print("Author: Pradeep")
print("")

def get_matrix(name):
    rows = int(input("Enter number of rows for " + name + ": "))
    cols = int(input("Enter number of cols for " + name + ": "))
    print("Enter values row by row (space separated):")
    data = []
    for i in range(rows):
        row = list(map(float, input("Row " + str(i+1) + ": ").split()))
        data.append(row)
    return np.array(data)

while True:
    print("----------------------------------")
    print("1. Addition")
    print("2. Subtraction")
    print("3. Multiplication")
    print("4. Transpose")
    print("5. Determinant")
    print("6. Exit")
    print("----------------------------------")
    choice = input("Enter choice: ")

    if choice == '1':
        a = get_matrix("Matrix A")
        b = get_matrix("Matrix B")
        print("Result:")
        print(a + b)

    elif choice == '2':
        a = get_matrix("Matrix A")
        b = get_matrix("Matrix B")
        print("Result:")
        print(a - b)

    elif choice == '3':
        a = get_matrix("Matrix A")
        b = get_matrix("Matrix B")
        print("Result:")
        print(np.dot(a, b))

    elif choice == '4':
        a = get_matrix("Matrix A")
        print("Transpose:")
        print(a.T)

    elif choice == '5':
        a = get_matrix("Matrix A")
        if a.shape[0] != a.shape[1]:
            print("Matrix must be square for determinant")
        else:
            print("Determinant:")
            print(np.linalg.det(a))

    elif choice == '6':
        print("Exiting...")
        break

    else:
        print("Invalid choice")
