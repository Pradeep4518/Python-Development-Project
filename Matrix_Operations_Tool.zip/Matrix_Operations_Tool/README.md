# Matrix Operations Tool

Author: Pradeep

## How to Run

```
pip install -r requirements.txt
python matrix_tool.py
```

## Features

- Addition
- Subtraction
- Multiplication
- Transpose
- Determinant

## Usage

Run the script and choose an option from the menu.
Enter matrix values row by row with spaces between numbers.
