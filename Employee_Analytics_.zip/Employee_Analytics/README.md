# Employee Analytics

> Data analysis and visualization project using **Pandas**, **Matplotlib**, and **Seaborn**.  

---

## Project Structure

```
Employee_Analytics/
│
├── data/
│   └── employees.csv          ← 150-row synthetic employee dataset
│
├── outputs/
│   ├── bar_chart.png          ← Avg salary by department
│   ├── scatter_plot.png       ← Experience vs salary (with trend line)
│   ├── heatmap.png            ← Correlation heatmap
│   └── analysis.txt           ← Full text report with insights
│
├── employee_analytics.py      ← Main script (run this)
├── README.md
└── requirements.txt
```

---

## Setup

```bash
# 1. Clone / download the project
cd Employee_Analytics

# 2. Install dependencies
pip install -r requirements.txt

# 3. Run the script
python employee_analytics.py
```

---

## Dataset — `data/employees.csv`

| Column | Type | Description |
|---|---|---|
| `Name` | str | Employee ID (EMP001 … EMP150) |
| `Department` | str | Engineering / Marketing / Sales / HR / Finance |
| `Age` | int | Employee age in years |
| `Experience_Years` | int | Years of professional experience |
| `Salary` | int | Annual salary in USD |
| `Performance` | float | Performance score (1.0 – 5.0) |

---

## Outputs

### Bar Chart — `outputs/bar_chart.png`
Average salary per department, ranked highest → lowest.  
Engineering leads at **~$50k**; HR is lowest at **~$28k**.

### Scatter Plot — `outputs/scatter_plot.png`
Experience (years) vs Salary, colour-coded by department.  
Includes a least-squares trend line and ±$6k confidence band.  
Each year of experience adds approximately **$4,330** to salary (r = 0.89).

### Heatmap — `outputs/heatmap.png`
Pearson correlation matrix across Salary, Experience, Performance, and Age.  
Strong positive: Experience ↔ Salary (0.89), Experience ↔ Age (0.92).  
Weak positive: Performance ↔ Salary (0.27).

### Analysis Report — `outputs/analysis.txt`
Full text report including descriptive stats, per-department averages,
correlation matrix, and five key business insights.

---

## Key Insights

1. **Engineering pays the most** — $22k above HR (lowest)
2. **Experience is the strongest salary predictor** — r = 0.89
3. **Senior employees earn 191% more** than junior employees
4. **Performance scores are similar** across all departments (~3.5–3.7 / 5)
5. **Age and Experience are nearly identical** as predictors (r = 0.92 with each other)

---

## Tech Stack

| Library | Purpose |
|---|---|
| `pandas` | Data loading, groupby, describe, correlation |
| `matplotlib` | Bar chart, scatter plot, figure layout |
| `seaborn` | Heatmap with diverging colour map |
| `numpy` | Random data generation, polyfit trend line |

---

