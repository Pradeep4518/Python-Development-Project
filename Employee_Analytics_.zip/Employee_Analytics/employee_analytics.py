"""
============================================================
  Employee Analytics
  Author  : Pradeep
  Desc    : Load CSV → Analyse with Pandas → Visualise with Matplotlib
============================================================
  Run  :  python employee_analytics.py
  Deps :  pip install -r requirements.txt
============================================================
"""

import os
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
warnings.filterwarnings('ignore')

# ── Paths ──────────────────────────────────────────────────
DATA_DIR   = 'data/employees.csv'
OUTPUT_DIR = 'outputs'
os.makedirs(OUTPUT_DIR, exist_ok=True)

# ── Palette ────────────────────────────────────────────────
BG    = '#07090F'
PANEL = '#0E1118'
BORD  = '#1C2333'
ACC   = '#4F8EF7'
GRN   = '#34D399'
YLW   = '#FBBF24'
PRP   = '#A78BFA'
RED   = '#F87171'
TXT   = '#E2E8F0'
MUT   = '#64748B'

DEPT_C = {
    'Engineering': ACC, 'Marketing': GRN,
    'Sales': YLW,       'HR': RED,  'Finance': PRP,
}

plt.rcParams.update({
    'figure.facecolor': BG,    'axes.facecolor':  PANEL,
    'axes.edgecolor':   BORD,  'axes.labelcolor': TXT,
    'axes.titlecolor':  TXT,   'xtick.color':     MUT,
    'ytick.color':      MUT,   'text.color':      TXT,
    'font.family':      'DejaVu Sans',
    'grid.color':       BORD,  'grid.linewidth':  0.7,
    'axes.grid':        True,  'axes.axisbelow':  True,
})

# ══════════════════════════════════════════════════════════
# STEP 1 — LOAD DATA
# ══════════════════════════════════════════════════════════
print("\n[1] Loading dataset...")
df = pd.read_csv(DATA_DIR)
print(f"    Loaded {len(df)} rows × {len(df.columns)} columns")
print(f"    Columns : {', '.join(df.columns)}\n")

# ══════════════════════════════════════════════════════════
# STEP 2 — BASIC ANALYSIS
# ══════════════════════════════════════════════════════════
print("[2] Running Pandas analysis...")

avg_salary     = df['Salary'].mean()
avg_experience = df['Experience_Years'].mean()
avg_perf       = df['Performance'].mean()

print(f"    Avg Salary          : ${avg_salary:,.0f}")
print(f"    Avg Experience      : {avg_experience:.1f} years")
print(f"    Avg Performance     : {avg_perf:.2f} / 5.0")

dept_salary = df.groupby('Department')['Salary'].mean().sort_values(ascending=False)
print(f"\n    Avg Salary by Dept  :")
for d, v in dept_salary.items():
    print(f"      {d:<15} ${v:>8,.0f}")

# ══════════════════════════════════════════════════════════
# STEP 3 — HELPERS
# ══════════════════════════════════════════════════════════
def style(ax, title, subtitle=''):
    ax.set_title(title, fontsize=13, fontweight='bold', color=TXT, pad=12, loc='left')
    if subtitle:
        ax.text(0, 1.012, subtitle, transform=ax.transAxes, fontsize=8.5, color=MUT)
    for sp in ax.spines.values():
        sp.set_color(BORD)
        sp.set_linewidth(0.8)
    ax.tick_params(length=0)

def save(fig, name):
    path = os.path.join(OUTPUT_DIR, name)
    fig.savefig(path, dpi=160, bbox_inches='tight',
                facecolor=BG, pad_inches=0.2)
    plt.close(fig)
    print(f"    Saved → outputs/{name}")

# ══════════════════════════════════════════════════════════
# STEP 4 — BAR CHART
# ══════════════════════════════════════════════════════════
print("\n[3] Generating bar_chart.png ...")
fig, ax = plt.subplots(figsize=(10, 6), facecolor=BG)
fig.subplots_adjust(left=0.13, right=0.95, top=0.88, bottom=0.13)

dept_avg = df.groupby('Department')['Salary'].mean().sort_values(ascending=False)
colors   = [DEPT_C[d] for d in dept_avg.index]

bars = ax.bar(dept_avg.index, dept_avg.values, color=colors,
              width=0.55, edgecolor='none', zorder=2)
for bar, val, col in zip(bars, dept_avg.values, colors):
    ax.bar(bar.get_x(), val, width=bar.get_width(),
           color=col, alpha=0.10, zorder=1)
    ax.text(bar.get_x() + bar.get_width() / 2, val + 700,
            f'${val/1000:.1f}k', ha='center',
            fontsize=9, color=TXT, fontweight='bold')

ax.set_xlabel('Department', fontsize=10, color=MUT, labelpad=8)
ax.set_ylabel('Average Salary (USD)', fontsize=10, color=MUT, labelpad=8)
ax.set_ylim(0, dept_avg.max() * 1.18)
ax.grid(axis='y', alpha=0.35)
ax.grid(axis='x', visible=False)
style(ax, 'Average Salary by Department', 'Ranked highest → lowest')
save(fig, 'bar_chart.png')

# ══════════════════════════════════════════════════════════
# STEP 5 — SCATTER PLOT
# ══════════════════════════════════════════════════════════
print("[4] Generating scatter_plot.png ...")
fig, ax = plt.subplots(figsize=(10, 6), facecolor=BG)
fig.subplots_adjust(left=0.12, right=0.97, top=0.88, bottom=0.13)

for dept, grp in df.groupby('Department'):
    ax.scatter(grp['Experience_Years'], grp['Salary'],
               c=DEPT_C[dept], label=dept, s=55,
               alpha=0.82, edgecolors='none', zorder=3)

m, b = np.polyfit(df['Experience_Years'], df['Salary'], 1)
xs   = np.linspace(df['Experience_Years'].min(), df['Experience_Years'].max(), 200)
ys   = m * xs + b
ax.plot(xs, ys, color=RED, lw=2, ls='--', zorder=4, label='Trend')
ax.fill_between(xs, ys - 6000, ys + 6000, color=RED, alpha=0.07)
ax.annotate(f'≈ ${m:,.0f} / yr',
            xy=(xs[-1], ys[-1]), xytext=(-85, 20),
            textcoords='offset points', color=RED, fontsize=9,
            arrowprops=dict(arrowstyle='->', color=RED, lw=1.2))

ax.set_xlabel('Experience (Years)', fontsize=10, color=MUT, labelpad=8)
ax.set_ylabel('Salary (USD)', fontsize=10, color=MUT, labelpad=8)
ax.legend(fontsize=8.5, frameon=False, labelcolor=TXT, ncol=3, loc='upper left')
style(ax, 'Experience vs Salary', 'Each dot = one employee  |  shaded band = ±$6k confidence')
save(fig, 'scatter_plot.png')

# ══════════════════════════════════════════════════════════
# STEP 6 — HEATMAP
# ══════════════════════════════════════════════════════════
print("[5] Generating heatmap.png ...")
fig, ax = plt.subplots(figsize=(7, 6), facecolor=BG)
fig.subplots_adjust(left=0.18, right=0.95, top=0.88, bottom=0.18)

corr = df[['Salary', 'Experience_Years', 'Performance', 'Age']].corr()
cmap = sns.diverging_palette(230, 15, s=85, l=45, as_cmap=True)
sns.heatmap(
    corr, ax=ax, cmap=cmap, vmin=-1, vmax=1,
    annot=True, fmt='.2f',
    annot_kws={'size': 11, 'color': TXT, 'weight': 'bold'},
    linewidths=1.5, linecolor=BG,
    cbar_kws={'shrink': 0.8, 'pad': 0.03})
ax.tick_params(labelsize=9, length=0)
ax.set_xticklabels(ax.get_xticklabels(), rotation=30, ha='right', color=MUT)
ax.set_yticklabels(ax.get_yticklabels(), rotation=0, color=MUT)
style(ax, 'Correlation Heatmap', 'Pearson r  |  values near ±1 = strong linear relationship')
save(fig, 'heatmap.png')

# ══════════════════════════════════════════════════════════
# STEP 7 — ANALYSIS REPORT
# ══════════════════════════════════════════════════════════
print("[6] Writing analysis.txt ...")

dept_perf  = df.groupby('Department')['Performance'].mean().sort_values(ascending=False)
senior     = df[df['Experience_Years'] >= 8]
junior     = df[df['Experience_Years'] <= 3]
exp_sal_r  = df['Experience_Years'].corr(df['Salary'])
exp_perf_r = df['Experience_Years'].corr(df['Performance'])
top_dept   = dept_avg.idxmax()
low_dept   = dept_avg.idxmin()

lines = []
lines.append("=" * 62)
lines.append("  EMPLOYEE DATA — ANALYSIS REPORT")
lines.append("  Author : Pradeep")
lines.append("=" * 62)

lines.append("\n── DATASET OVERVIEW ──────────────────────────────────────────")
lines.append(f"  Total Employees   : {len(df)}")
lines.append(f"  Departments       : {df['Department'].nunique()}")
lines.append(f"  Columns           : {', '.join(df.columns)}")

lines.append("\n── DESCRIPTIVE STATISTICS ────────────────────────────────────")
lines.append(df[['Age', 'Experience_Years', 'Salary', 'Performance']].describe().round(2).to_string())

lines.append("\n── AVERAGE SALARY BY DEPARTMENT ──────────────────────────────")
for dept, val in dept_avg.items():
    bar = '█' * int(val / 3000)
    lines.append(f"  {dept:<15} ${val:>8,.0f}  {bar}")

lines.append("\n── AVERAGE PERFORMANCE BY DEPARTMENT ─────────────────────────")
for dept, val in dept_perf.items():
    stars = '★' * round(val) + '☆' * (5 - round(val))
    lines.append(f"  {dept:<15} {val:.2f}  {stars}")

lines.append("\n── CORRELATION MATRIX ────────────────────────────────────────")
lines.append(corr.round(3).to_string())

lines.append("\n── KEY INSIGHTS ──────────────────────────────────────────────")
lines.append(f"  1. {top_dept} pays the highest avg salary  (${dept_avg[top_dept]:,.0f})")
lines.append(f"     {low_dept} pays the lowest avg salary   (${dept_avg[low_dept]:,.0f})")
lines.append(f"     Pay gap between top and bottom: ${dept_avg[top_dept] - dept_avg[low_dept]:,.0f}")
lines.append(f"\n  2. Each year of experience adds ≈ ${m:,.0f} to salary")
lines.append(f"     Correlation (Experience ↔ Salary)     : r = {exp_sal_r:.3f}  [strong positive]")
lines.append(f"     Correlation (Experience ↔ Performance): r = {exp_perf_r:.3f}  [weak positive]")
lines.append(f"\n  3. {dept_perf.idxmax()} leads in avg performance score"
             f" ({dept_perf.max():.2f} / 5)")
lines.append(f"\n  4. Senior employees (8+ yrs) avg salary : ${senior['Salary'].mean():,.0f}")
lines.append(f"     Junior employees (1–3 yrs) avg salary : ${junior['Salary'].mean():,.0f}")
lines.append(f"     Senior premium over juniors            : "
             f"{(senior['Salary'].mean() / junior['Salary'].mean() - 1) * 100:.1f}%")
lines.append(f"\n  5. Headcount by department:")
for dept, cnt in df['Department'].value_counts().items():
    pct = cnt / len(df) * 100
    lines.append(f"     {dept:<15} {cnt:>3} employees  ({pct:.1f}%)")

lines.append("\n" + "=" * 62)
lines.append("  End of Report")
lines.append("=" * 62 + "\n")

report = "\n".join(lines)
with open(os.path.join(OUTPUT_DIR, 'analysis.txt'), 'w') as f:
    f.write(report)
print("    Saved → outputs/analysis.txt")

print("\n✔  All done! Check the outputs/ folder.\n")
